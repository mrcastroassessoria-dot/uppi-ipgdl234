import { ReactNode } from "react"

export default function PhoneLayout({ children }: { children: ReactNode }) {
  return <>{children}</>
}
